# coding=utf-8
import re
import psycopg2
import shutil
	
conn=psycopg2.connect(database="postgres",user="ysys",password="ysys",host="192.168.1.103",port="5432")
cur=conn.cursor() 

path = 'D:\\github\\ysys\\README.md'
path2 = 'D:\\github\\ysys\\READMETMP.md'

f = open(path2,'w',encoding='utf-8')
with open(path,'r',encoding='utf-8') as r:
	for line in r:
		if not re.search('every',line):
			f.write(line)
		else:
			break
f.close()
r.close()


cur.execute("select public.test_t_wj_fxjh_link()")
cur.execute("select textadd from test.t_wj_fxjh_link order by link desc")
rows = cur.fetchall()
f = open('D:\\github\\ysys\\READMETMP.md','a',encoding='utf-8')

f.write('## every'+'\n')
for row in rows:
	f.write(str(row).replace("('",'').replace("',)",'')+'\n'+'\r'+'\n')
f.close()
shutil.move(path2,path)
conn.commit()
conn.close()
