#coding=utf-8
import xlwt
import psycopg2

conn = psycopg2.connect(database="postgres", user="ysys", password="ysys", host="192.168.1.103", port="5432")
cur = conn.cursor()

cur.execute("select h.filefull,h.learn,h.label,h.study_counts,h.filefull  filefull_2, '=hyperlink(E'||f.id||',A'||f.id||')' as link  from (select filefull,null as learn,label as label,study_counts,row_number() over(order by filefull_mtimes desc) as cn   from test.t_wj_fxjh where study_day <= date(now()) and filefull_sizes <> 0 order by filefull_mtimes  desc,filefull desc) h,(select generate_series(2,31) as id ) as f where h.cn +1 =f.id")
rows = cur.fetchall()
i = 1
"""
for row in rows:
	print(i,row[0],row[1],row[2],row[3],row[4],row[5])
	print("----------------------------------------")
	i = i + 1
"""


wb = xlwt.Workbook()
# sheet页名称
sh1 = wb.add_sheet('Sheet1')
# 字段名
sh1.write(0,0,'filefull')
sh1.write(0,1,'learn')
sh1.write(0,2,'label')
sh1.write(0,3,'study_counts')
sh1.write(0,4,'filefull_2')
sh1.write(0,5,'link')

for row in rows:
	sh1.write(i,0,row[0])
	sh1.write(i,1,row[1])
	sh1.write(i,2,row[2])
	sh1.write(i,3,row[3])
	sh1.write(i,4,row[4])
	sh1.write(i,5,row[5])
	i = i + 1

# 保存excel文件路径明确
wb.save('C:\\Users\\guohui\\Documents\\file.xls')
conn.commit()
conn.close()
