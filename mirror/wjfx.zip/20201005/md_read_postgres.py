# coding=utf-8
import os
import sys
import time
import datetime
import psycopg2
def get_file_create_time(path):
	t = os.path.getctime(path)
	times = datetime.datetime.fromtimestamp(t)
	return times;

def get_file_visit_time(path):
	t = os.path.getatime(path)
	times = datetime.datetime.fromtimestamp(t)
	return times;
	
	
def get_file_modify_time(path):
	t = os.path.getmtime(path)
	times = datetime.datetime.fromtimestamp(t)
	return times;
	
def get_file_size(path):
	fsize=os.path.getsize(path)
	return fsize;
	
conn=psycopg2.connect(database="postgres",user="ysys",password="ysys",host="192.168.1.103",port="5432")
cur=conn.cursor() 

cur.execute("truncate table test.t_wj_fxjh_zjb")
cur.execute("truncate table test.t_wj_fxjh_txt")
path = "D:\\github\\ysys\\every"
g = os.walk(path)

for pathf,dir_list,file_list in g:
	for file_name in file_list:
		filefull = os.path.join(pathf,file_name)
		
		filefull_ctimes = get_file_create_time(filefull)
		filefull_atimes = get_file_visit_time(filefull)
		filefull_mtimes = get_file_modify_time(filefull)
		filefull_sizes = get_file_size(filefull)
		cur.execute("insert into test.t_wj_fxjh_zjb(filefull,filefull_ctimes,filefull_atimes, filefull_mtimes,filefull_sizes) VALUES(%s,%s,%s,%s,%s)",(filefull,filefull_ctimes,filefull_atimes,filefull_mtimes,filefull_sizes))
		
		try:
		
			file_text = open(filefull,"r",encoding='UTF-8')
			filetext = '';
			for line in file_text:
				line = "".join(line)
				line = line.strip('\n')
				#line = line.split(",")
				#content = line[0]
				filetext = filetext+line
			filetext2 = filetext
			cur.execute("insert into test.t_wj_fxjh_txt(filefull,filefull_ctimes,filefull_atimes, filefull_mtimes,filetext) VALUES(%s,%s,%s,%s,%s)",(filefull,filefull_ctimes,filefull_atimes,filefull_mtimes,filetext2))
			file_text.close()
		
		except Exception as e:
			
			print(e)
			cur.execute("insert into test.t_wj_fxjh_txt(filefull,filefull_ctimes,filefull_atimes, filefull_mtimes,filetext) VALUES(%s,%s,%s,%s,%s)",(filefull,filefull_ctimes,filefull_atimes,filefull_mtimes,'数据异常'))
		finally:
			print('结束')
		
	
cur.execute("select public.f_get_review()")	
conn.commit()
conn.close()
