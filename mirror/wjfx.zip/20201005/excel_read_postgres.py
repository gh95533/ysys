import xlrd
import psycopg2

conn = psycopg2.connect(database="postgres", user="ysys", password="ysys", host="192.168.1.103", port="5432")
cur = conn.cursor()
cur.execute("truncate table test.t_wj_fxjh_lsb")

loc = ("C:\\Users\\guohui\\Documents\\file.xls")

wb = xlrd.open_workbook(loc)
table = wb.sheet_by_index(0)
for rowNum in range(table.nrows):
	if rowNum > 0:
		v_filefull = str(table.row_values(rowNum)[0])
		v_learn = str(table.row_values(rowNum)[1])
		v_label = str(table.row_values(rowNum)[2])
		#print(v_filefull,v_learn,v_label)
		cur.execute("insert into test.t_wj_fxjh_lsb(filefull,learn,label) values(%s,%s,%s)",(v_filefull,v_learn,v_label))

conn.commit()
conn.close()
